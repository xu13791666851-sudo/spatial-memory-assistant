# I SEE YOU · 空间记忆助手

## 语音与识图并行反馈候选版

在 0.17 基础上，视觉处理与简短语音反馈并行，快速结果跳过提示语，正式结果优先播报；新指令或取消会作废旧任务回复，并复用新鲜检测结果。电脑端 94 项检查、Python 3 项跟踪检查通过。

**本次需要更新电脑源码并重新构建、安装安卓 APK。** 当前交付为源码更新包，尚未完成新版 APK 编译或实物端到端延迟验收。见[实现与验收说明](docs/parallel-feedback.md)、[源码更新包](packages/parallel-feedback-source.zip)及 [SHA-256](packages/parallel-feedback-source.zip.sha256)。

## 0.17 Omni Realtime 候选版

本分支电脑端默认使用 **qwen3.8-omni-flash-realtime**，不再等待 Jev，也不调用非实时 Omni 或 VL。现有安卓 0.16 的 Realtime 语音、界面、配对与备份协议继续兼容。代码与公共图片接口检查已完成，华为 MateBook X Pro 2020 / 小米 Pad 5 实物联调尚未执行。见 [本轮改动、验证和测试步骤](docs/omni-realtime-0.17.md)。下方 0.16 记录作为历史验收边界保留。

## 安卓与电脑处理开发进度

本分支包含0.16安卓平板、电脑端物品记忆与找物的当前实现。平板连接、画面传输、本地检测和历史位置读取已验证；参考照片质量、Jev稳定对比及完整找物仍待验收。电脑端66项流程检查和安卓75项本地检查通过，不能代替真实找物准确率验收。

请先查看[当前完成情况与待解决问题](docs/current-progress-2026-11-05.md)，电脑服务的启动见[使用说明](pc-gateway/README.md)。以下网页说明保留原有入口，网页与本分支的电脑端记忆并不自动共享。


**看见日常，也看见你。**

I SEE YOU 面向视障用户，把摄像头画面、语音对话和物品记忆连接起来。用户可以询问眼前有什么、记住物品，再用过去的记录作为寻找线索。它会区分“上次记录的位置”和“这次画面确认的位置”。[了解产品故事与无障碍方案](docs/unified-accessibility-plan.md)。

看和听是不同的感官，却可以一起回答“它在哪里”。声音引导观察，画面回应询问，记忆连接起一次次对话。“I SEE YOU”也意味着看见每个人具体的需要：有人想听一句提示，有人想放大画面，有人想回看昨天的记录。我们希望把选择权留给用户。

## 从哪里开始

| 你想做什么 | 入口 | 当前状态 |
| --- | --- | --- |
| 直接打开已上线的基础网页 | [I SEE YOU 网页](https://i-see-you-spatial-memory.pages.dev/video/) | 手机或电脑浏览器可访问；使用浏览器保存记录 |
| 试用浏览器内的 YOLO 找物 | [YOLO 测试页](https://i-see-you-yolo-preview.pages.dev/video/) | 已上线的独立测试入口；仍不是下方的完整三样本演示 |
| 查看完整手机摄像头演示 | [演示说明](docs/hackathon-web-demo.md) | 源码和打包流程已在 `main`；需要支持 Python 的服务单独部署，**上方网址不是这个完整演示** |
| 获取安卓测试包 | [安卓说明](android/README.md) · [最近的构建记录](https://github.com/xu13791666851-sudo/spatial-memory-assistant/actions/workflows/android-test.yml) | 构建记录提供有期限的安装包；安卓真机麦克风和实体 ESP32 尚待验证 |
| 准备黑客松 ZIP 作品材料 | [中文作品包说明](docs/hackathon-submission.md) | 整理源码、APK、封面、界面图和验证记录，并明确仍缺少的材料 |
| 查看设计与部署资料 | [文档目录](docs/README.md) | 图稿、测试说明、平台配置和历史记录集中在这里 |

完整网页演示用手机摄像头、后台 YOLO、三次外观样本和千问核对完成记忆与找物；安卓测试包则在手机本机运行 YOLO，并保留 ESP32 配网与画面来源切换。两者界面接近，但运行方式和数据存储不同，记录不会自动同步。网页演示的硬件部分独立展示。

## 仓库里的内容

| 目录 | 用途 |
| --- | --- |
| `web/`、`cloudflare/`、`netlify/` | 基础网页及其线上服务；Cloudflare 为当前正式入口，Netlify 为旧部署 |
| `demo/` | 完整手机摄像头网页演示的后台 |
| `android/` | 安卓原生应用、测试和 ESP32 固件 |
| `models/yolo/` | 网页演示和安卓构建使用的原始模型与标签 |
| `src/` | 早期本地 Python 原型，仍可独立运行 |
| `designs/`、`docs/` | 界面图稿、产品方案、部署说明与历史记录 |
| `scripts/`、`tests/` | 构建、打包和检查 |

主分支是当前整合版本。旧测试分支留作历史快照；新改动应从 `main` 开始，经过检查后再合回 `main`。详见[维护说明](docs/README.md#版本与分支)。

## 本地运行完整网页演示

需要 Node.js 22 和 Python 3.11。千问长期密钥仅放在服务器环境变量 `QWEN_API_KEY`，不要写入网页、安装包或仓库。

```sh
npm ci
npm run build:demo
python -m pip install -r demo/requirements.txt
python -m uvicorn demo.server:app --host 0.0.0.0 --port 7860
```

电脑打开 `http://127.0.0.1:7860/`。手机摄像头和麦克风需要可访问的 HTTPS 地址；部署步骤见[完整演示说明](docs/hackathon-web-demo.md)。安卓构建与硬件步骤见[安卓说明](android/README.md)。基础网页的发布方式见[Cloudflare 部署说明](docs/cloudflare-deployment.md)。

## 验证范围

网页和安卓均有自动构建与检查：[完整网页演示](https://github.com/xu13791666851-sudo/spatial-memory-assistant/actions/workflows/web-demo.yml) · [安卓测试包](https://github.com/xu13791666851-sudo/spatial-memory-assistant/actions/workflows/android-test.yml)。自动检查不能代替 iPhone、安卓真机、真实物品识别和 ESP32 实物验收。

此前各测试版的详细记录保存在[历史首页说明](docs/history/README-2026-10-21.md)，仅供追溯；当前入口和状态以本页及对应专项文档为准。
